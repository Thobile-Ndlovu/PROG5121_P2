/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project1;

public class Login {
    private static String registeredUsername;
    private static String registeredPassword;
    private static String registeredFirstName;
    private static String registeredLastName;

    public static void setRegisteredUserDetails(String username, String password, String firstName, String lastName) {
        Login.registeredUsername = username;
        Login.registeredPassword = password;
        Login.registeredFirstName = firstName;
        Login.registeredLastName = lastName;
    }

    public static boolean checkUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            return false;
        }
        return username.length() <= 5 && username.contains("_");
    }

    public static boolean checkPasswordComplexity(String password) {
        if (password == null || password.trim().isEmpty()) {
            return false;
        }
        boolean hasUppercase = !password.equals(password.toLowerCase());
        boolean hasDigit = password.matches(".*\\d.*");
        boolean hasSpecialChar = !password.matches("[A-Za-z0-9]*");
        return password.length() >= 8 && hasUppercase && hasDigit && hasSpecialChar;
    }

    public static boolean validateCellphoneNumber(String cellphoneNumber) {
        if (cellphoneNumber == null || cellphoneNumber.trim().isEmpty()) {
            return false;
        }
        return cellphoneNumber.startsWith("+27") && cellphoneNumber.length() == 12 && cellphoneNumber.substring(3).matches("\\d+");
    }

    public static boolean loginUser(String username, String password) {
        return registeredUsername != null && registeredPassword != null &&
               registeredUsername.equals(username) && registeredPassword.equals(password);
    }

    public static String returnLoginStatus(boolean isLoginSuccessful) {
        if (isLoginSuccessful) {
            return "Welcome " + registeredFirstName + " " + registeredLastName + ", it is great to see you.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}