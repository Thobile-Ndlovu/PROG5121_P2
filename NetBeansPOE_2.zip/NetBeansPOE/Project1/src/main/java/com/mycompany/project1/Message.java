package com.mycompany.project1;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Message {

    private String recipient;
    private String messageContent;
    private int totalMessagesSent = 0;
    private List<String> sentMessagesList = new ArrayList<>();
    
    //  Set to package-private so Project1NGTest can access it without compilation errors.
    String currentMessageID = "";

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public void setMessageContent(String messageContent) {
        this.messageContent = messageContent;
    }

    // --- In Message.java ---

public boolean checkRecipientCall(String callNumber) {
    if (callNumber == null || callNumber.trim().isEmpty()) {
        return false;
    }
    // FIX: Confirmed logic to match a '+' followed by exactly 11 digits (12 characters total).
    return callNumber.matches("^[+]\\d{11}$");
}
    public boolean checkMessageLength(String message) {
        if (message == null || message.trim().isEmpty()) {
            return false;
        }
        return message.length() <= 250;
    }

    public String createMessageID() {
        Random rand = new Random();
        // Generates a random 10-digit number
        long tenDigitId = (long) (rand.nextDouble() * 9000000000L) + 1000000000L;
        this.currentMessageID = String.valueOf(tenDigitId);
        return this.currentMessageID;
    }

    public String createMessageHash() {
        if (messageContent == null || messageContent.trim().isEmpty() || currentMessageID.length() < 2) {
            return "ERROR: INVALID_STATE";
        }
        String messageIDPrefix = currentMessageID.substring(0, 2);
        
        // Remove punctuation/special chars and convert to uppercase
        String cleanedContent = messageContent.trim().toUpperCase().replaceAll("[^A-Z0-9\\s]", " ");
        String[] words = cleanedContent.split("\\s+");
        
        String firstWord = words.length > 0 && !words[0].isEmpty() ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;

        return messageIDPrefix + ":" + firstWord + lastWord;
    }

    public String send(String option, String messageID, String messageHash) {
        String fullMessageDetails = String.format("MessageID: %s | Hash: %s | Recipient: %s | Message: %s",
                                                  messageID, messageHash, recipient, messageContent);

        switch (option) {
            case "1": 
                totalMessagesSent++;
                sentMessagesList.add("SENT | " + fullMessageDetails);
                return "Message successfully sent.\nPress D to delete message.";
            case "2": 
                return "Message discarded.";
            case "3": 
                sentMessagesList.add("STORED | " + fullMessageDetails);
                return "Message successfully stored.";
            case "4": 
                return "ChatGPT feature placeholder invoked.";
            default:
                return "Invalid option selected. Message discarded.";
        }
    }

    public String printMessages() {
        if (sentMessagesList.isEmpty()) {
            return "No messages were sent or stored during this session.";
        }
        StringBuilder sb = new StringBuilder("--- All Messages Processed (Sent/Stored) ---\n");
        for (String msg : sentMessagesList) {
            sb.append(msg).append("\n");
        }
        return sb.toString();
    }

    public int returnTotalMessageSent() {
        return totalMessagesSent;
    }
}