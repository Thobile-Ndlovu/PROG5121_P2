/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package com.mycompany.project1;

import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author RC_Student_lab
 */
public class Project1NGTest {
    
    // A single Message object to be reset before each test
    private Message message;
    
    public Project1NGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
        // Clear static state before each Login test to ensure independence
        Login.setRegisteredUserDetails(null, null, null, null);
        
        // Initialize Message object for all Message tests
        message = new Message();    
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }
    
    // =========================================================================
    //                            LOGIN CLASS TESTS
    // =========================================================================
    
    @Test
    public void testCheckUsername_CorrectlyFormatted() {
        System.out.println("checkUsername - Correctly Formatted");
        String username = "kyl_1";      
        assertTrue(Login.checkUsername(username));
    }
    
    @Test
    public void testCheckUsername_TooLong() {
        System.out.println("checkUsername - Too Long");
        String username = "long_user";
        assertFalse(Login.checkUsername(username));
    }
    
    // =========================================================================
    //                            MESSAGE CLASS TESTS
    // =========================================================================
    
    @Test
    public void testCheckRecipientCall_CorrectlyFormatted() {
        System.out.println("Message - checkRecipientCall - Success");
        String callNumber = "+277118693002"; // 12 characters, starts with +
        assertTrue(message.checkRecipientCall(callNumber), "Recipient number should be correctly formatted.");
    }

    @Test
    public void testCheckRecipientCall_IncorrectlyFormatted() {
        System.out.println("Message - checkRecipientCall - Failure");
        String callNumber = "0857975889"; // Missing international code/too short
        assertFalse(message.checkRecipientCall(callNumber), "Recipient number should fail without international code (+).");
    }

    @Test
    public void testCheckRecipientCall_TooLong() {
        System.out.println("Message - checkRecipientCall - Too Long");
        String callNumber = "+2771186930021"; // 13 characters
        assertFalse(message.checkRecipientCall(callNumber), "Recipient number should fail if too long.");
    }

    @Test
    public void testCheckMessageLength_UnderLimit() {
        System.out.println("Message - checkMessageLength - Success");
        String content = "Hi Mike, can you join us for dinner tonight?";
        assertTrue(message.checkMessageLength(content), "Message length should be valid.");
    }

    @Test
    public void testCheckMessageLength_OverLimit() {
        System.out.println("Message - checkMessageLength - Failure");
        // Create a 251-character string
        String content = new String(new char[251]).replace('\0', 'A');
        assertFalse(message.checkMessageLength(content), "Message length should fail if over 250 characters.");
    }
    
    @Test
    public void testCheckMessageLength_Empty() {
        System.out.println("Message - checkMessageLength - Empty");
        String content = "";
        assertFalse(message.checkMessageLength(content), "Message length should fail if empty.");
    }
    
    @Test
    public void testCreateMessageID_LengthAndUniqueness() {
        System.out.println("Message - createMessageID - Length and Uniqueness");
        String id1 = message.createMessageID();
        String id2 = new Message().createMessageID(); // New instance for better ID isolation
        
        assertEquals(id1.length(), 10, "MessageID should be exactly 10 digits long.");
        assertNotEquals(id1, id2, "Two generated IDs should be different (randomly unique).");
    }

    @Test
    public void testCreateMessageHash_CorrectFormat_Test1() {
        System.out.println("Message - createMessageHash - Test Data 1");
        
        // Setup message and an ID to ensure a predictable prefix for the test
        message.setMessageContent("Hi Mike, can you join us for dinner tonight?");
        String mockID = "0012345678";
        // Directly set the ID used for the hash prefix (relies on Message.java fix 1.B)
        message.createMessageID(); // Just to set the internal state
        message.currentMessageID = mockID;
        
        String expectedHash = "00:HITONIGHT"; 
        String actualHash = message.createMessageHash();
        
        assertEquals(actualHash, expectedHash, "Message Hash should match the format XX:FIRSTWORDLASTWORD in caps.");
    }
    
    @Test
    public void testCreateMessageHash_HandlesPunctuation() {
        System.out.println("Message - createMessageHash - Handles Punctuation");
        
        // Setup message with punctuation
        message.setMessageContent("Is this message, right?");
        String mockID = "1298765432";
        message.createMessageID();
        message.currentMessageID = mockID;
        
        // Punctuation should be removed, resulting in "ISRIGHT"
        String expectedHash = "12:ISRIGHT";    
        String actualHash = message.createMessageHash();
        
        assertEquals(actualHash, expectedHash, "Message Hash should remove punctuation and use caps.");
    }
    
    @Test
    public void testSendMessage_Option1_Send() {
        System.out.println("Message - send - Option 1 (Send)");
        message.setRecipient("+277118693002");
        message.setMessageContent("Test send message.");
        String messageID = message.createMessageID();
        String messageHash = message.createMessageHash();
        
        String expected = "Message successfully sent.\nPress D to delete message.";
        String actual = message.send("1", messageID, messageHash);
        
        assertEquals(actual, expected, "The return message for sending should match the requirement.");
        assertEquals(message.returnTotalMessageSent(), 1, "Total messages sent should be 1.");
    }
    
    @Test
    public void testSendMessage_Option2_Discard() {
        System.out.println("Message - send - Option 2 (Disregard)");
        message.setRecipient("+277118693002");
        message.setMessageContent("Test discard message.");
        String messageID = message.createMessageID();
        String messageHash = message.createMessageHash();
        
        String expected = "Message discarded.";
        String actual = message.send("2", messageID, messageHash);
        
        assertEquals(actual, expected, "The return message for discarding should match the requirement.");
        assertEquals(message.returnTotalMessageSent(), 0, "Total messages sent should be 0.");
    }

    @Test
    public void testSendMessage_Option3_Store() {
        System.out.println("Message - send - Option 3 (Store)");
        message.setRecipient("+277118693002");
        message.setMessageContent("Test store message.");
        String messageID = message.createMessageID();
        String messageHash = message.createMessageHash();
        
        String expected = "Message successfully stored.";
        String actual = message.send("3", messageID, messageHash);
        
        assertEquals(actual, expected, "The return message for storing should match the requirement.");
        assertEquals(message.returnTotalMessageSent(), 0, "Total messages sent should be 0 (stored messages don't count as sent).");
    }

    @Test
    public void testReturnTotalMessageSent_MultipleSends() {
        System.out.println("Message - returnTotalMessageSent - Multiple Sends");
        message.setRecipient("+277118693002");
        message.setMessageContent("Message 1");
        message.send("1", message.createMessageID(), message.createMessageHash()); // Sent
        message.setMessageContent("Message 2");
        message.send("3", message.createMessageID(), message.createMessageHash()); // Stored (Not Sent)
        message.setMessageContent("Message 3");
        message.send("1", message.createMessageID(), message.createMessageHash()); // Sent
        
        assertEquals(message.returnTotalMessageSent(), 2, "Total sent messages should be 2.");
    }

    @Test
    public void testPrintMessages_AllProcessed() {
        System.out.println("Message - printMessages - All Processed");
        message.setRecipient("+277118693002");
        
        // Message 1: Sent
        message.setMessageContent("Test Message 1");
        String id1 = message.createMessageID();
        String hash1 = message.createMessageHash();
        message.send("1", id1, hash1);    
        
        // Message 2: Stored
        message.setMessageContent("Test Message 2");
        String id2 = message.createMessageID();
        String hash2 = message.createMessageHash();
        message.send("3", id2, hash2);    
        
        String output = message.printMessages();
        
        assertTrue(output.contains("--- All Messages Processed (Sent/Stored) ---"), "Output should contain header.");
        assertTrue(output.contains("SENT | MessageID: " + id1), "Output should contain SENT message.");
        assertTrue(output.contains("STORED | MessageID: " + id2), "Output should contain STORED message.");
        assertTrue(output.contains("Message: Test Message 1"), "Output should contain content of message 1.");
    }
}